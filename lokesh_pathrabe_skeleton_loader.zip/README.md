# Skeleton Loader Approach


* Skeleton loader will be designed for each container component by composing smaller loader components like TitleLoader, BlockLoader, ButtonLoader from skeletonLoader folder

* Each Container component will have its loader defined in its own file.

* Skeleton loader of container component will reuse style classes of actual component to style the loader. This helps in maintaining consistency in loader and its component as they share styles.

* This approach also gives flexibility to design skeleton loaders in greater details for each container component quickly.


# Demo

* Execute to run dev server for demo

` yarn install `
` yarn start `
