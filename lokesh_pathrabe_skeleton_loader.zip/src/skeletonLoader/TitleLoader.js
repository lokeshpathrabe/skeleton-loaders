import "./loader.css";

const TitleLoader = () => {
  return <div className="skeleton title-loader" />
};

export default TitleLoader;
