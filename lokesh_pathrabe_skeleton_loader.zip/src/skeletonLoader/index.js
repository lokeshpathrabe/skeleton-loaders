import AvatarLoader from "./AvatarLoader";
import BlockLoader from "./BlockLoader";
import FooterLoader from "./FooterLoader";
import "./loader.css";

export {
    AvatarLoader,
    BlockLoader,
    FooterLoader,
}