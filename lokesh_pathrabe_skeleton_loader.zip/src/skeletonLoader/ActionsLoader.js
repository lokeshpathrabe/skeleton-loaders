import "./loader.css";

const ActionLoader = () => {
  return <div className="skeleton action-loader" />
};

export default ActionLoader;
